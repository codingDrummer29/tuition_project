/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author acer
 */
public class Row {
    private static int row;
    public static int getRow(){
        return row;
    }
    public static void setRow(){
        row++;
    }
    public static void setRow( int temp){
        row= temp;
    }


}
